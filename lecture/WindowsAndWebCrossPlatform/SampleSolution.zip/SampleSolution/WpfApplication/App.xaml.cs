﻿using System.ComponentModel.Composition.Hosting;
using System.Windows;
using System.ComponentModel.Composition;
using CrossPlatformApplication.Utils;
using CrossPlatformApplication.ViewManager;
using CrossPlatformApplication.ViewModel;
using MefContrib.Hosting.Interception;
using MefContrib.Hosting.Interception.Configuration;
using Microsoft.Mef.CommonServiceLocator;
using Microsoft.Practices.ServiceLocation;

namespace CrossPlatformApplication
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
        #region Injected properties

        [Import]
        public ChildViewManager ChildViewManager { private get; set; }

        #endregion

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Create interception configuration
            var cfg = new InterceptionConfiguration()
                .AddAopInterception();

            var container = new CompositionContainer(new InterceptingCatalog(new AggregateCatalog(new DirectoryCatalog(".", "*.exe"), new DirectoryCatalog(".", "*.dll")), cfg));
            var locator = new MefServiceLocator(container);
            ServiceLocator.SetLocatorProvider(() => locator);
            container.ComposeExportedValue<IServiceLocator>(locator);
            container.ComposeParts(this);

            new MainWindow { DataContext = locator.GetInstance<MainViewModel>() }.Show();
        }
    }
}
