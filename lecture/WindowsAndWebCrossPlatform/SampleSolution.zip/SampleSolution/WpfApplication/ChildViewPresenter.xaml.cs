﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using CrossPlatformApplication.ViewModel;

namespace CrossPlatformApplication
{
    /// <summary>
    /// Interaction logic for ChildViewPresenter.xaml
    /// </summary>
    public partial class ChildViewPresenter
    {
        /// <summary>
        /// Initializes a new instance
        /// </summary>
        public ChildViewPresenter()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Underlying View Model
        /// </summary>
        public IChildViewModel ViewModel
        {
            get
            {
                Debug.Assert(DataContext == null || DataContext is IChildViewModel);
                return (IChildViewModel)DataContext;
            }
        }

        /// <summary>
        /// Processes window closing
        /// </summary>
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);

            Debug.Assert(ViewModel != null);

            if (!ViewModel.IsClosed)
            {
                e.Cancel = true;
                ViewModel.Close();
            }
        }

        private void OnChildViewPresenterContentRendered(object sender, EventArgs e)
        {
            SizeToContent = SizeToContent.Manual;
        }
    }
}
