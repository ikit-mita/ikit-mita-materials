﻿using Microsoft.Practices.ServiceLocation;

namespace CrossPlatformApplication.Utils
{
    public static class ClassHelper
    {
        public static T TryGetInstance<T>(this IServiceLocator locator, string key)
            where T : class
        {
            try
            {
                return locator.GetInstance<T>(key);
            }
            catch (ActivationException)
            {
                return null;
            }
        }
    }
}
