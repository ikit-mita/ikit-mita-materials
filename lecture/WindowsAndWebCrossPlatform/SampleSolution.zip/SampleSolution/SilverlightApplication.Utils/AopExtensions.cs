﻿using System;
using System.Linq;
using MefContrib.Hosting.Interception.Configuration;

namespace CrossPlatformApplication.Utils
{
    [Flags]
    public enum Aspects
    {
        NotifyPropertyChanged = 1,
    }

    public static class AopExtensions
    {
        public const string AspectMetadata = "AspectMetadata";

        public static InterceptionConfiguration AddAopInterception(this InterceptionConfiguration interceptionConfiguration)
        {
            return interceptionConfiguration
                .AddInterceptionCriteria(
                    new PredicateInterceptionCriteria(
                        new PropertyChangedDynamicProxyExportInterceptor(),
                        def => def.ExportDefinitions.Any(export =>
                            export.Metadata.ContainsKey(AspectMetadata) && ((Aspects)export.Metadata[AspectMetadata] & Aspects.NotifyPropertyChanged) != 0)));
        }
    }
}
