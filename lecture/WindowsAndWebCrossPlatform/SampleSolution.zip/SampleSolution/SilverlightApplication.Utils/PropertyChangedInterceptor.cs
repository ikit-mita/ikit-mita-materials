﻿using System.ComponentModel;
using System.Linq;
using System.Reflection;
using Castle.DynamicProxy;

namespace CrossPlatformApplication.Utils
{
    internal class PropertyChangedInterceptor : IInterceptor
    {
        private event PropertyChangedEventHandler PropertyChanged;

        public void Intercept(IInvocation invocation)
        {
            string methodName = invocation.Method.Name;

            if (invocation.Method.IsSpecialName)
            {
                if (invocation.Method.DeclaringType == typeof (INotifyPropertyChanged))
                {
                    if (methodName.StartsWith("add_"))
                    {
                        PropertyChanged += (PropertyChangedEventHandler)invocation.Arguments[0];
                    }
                    else
                    {
                        PropertyChanged -= (PropertyChangedEventHandler)invocation.Arguments[0];
                    }

                    return;
                }

                if (methodName.StartsWith("set_"))
                {
                    PropertyInfo propertyInfo = invocation.Proxy.GetType().GetProperty(methodName.Substring(4));
                    object oldValue = propertyInfo.GetValue(invocation.Proxy, invocation.Arguments.Take(invocation.Arguments.Length - 1).ToArray());

                    invocation.Proceed();

                    if (oldValue == invocation.Arguments [invocation.Arguments.Length - 1])
                    {
                        return;
                    }

                    OnPropertyChanged(invocation.Proxy, new PropertyChangedEventArgs(propertyInfo.Name));

                    return;
                }
            }

            invocation.Proceed();
        }

        private void OnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            PropertyChangedEventHandler eventHandler = PropertyChanged;

            if (eventHandler != null)
            {
                eventHandler(sender, e);
            }
        }
    }
}
