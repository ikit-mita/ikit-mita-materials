﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using Castle.Core;
using Castle.DynamicProxy;
using MefContrib.Hosting.Interception;

namespace CrossPlatformApplication.Utils
{
    internal class PropertyChangedDynamicProxyExportInterceptor : IExportedValueInterceptor
    {
        private static readonly ProxyGenerator Generator = new ProxyGenerator();
        private readonly Type[] _additionalInterfaces = new[] { typeof(INotifyPropertyChanged) };
     
        public object Intercept(object value)
        {
            object proxy = Generator.CreateClassProxy(value.GetType(), _additionalInterfaces, new[] { new PropertyChangedInterceptor() });
     
            Type currentType = value.GetType();
     
            do
            {
                FieldInfo[] fields = currentType.GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public)
                    .Where(field => (field.Attributes & FieldAttributes.InitOnly) == 0)
                    .ToArray();

                fields.Select(field => new { Field = field, Value = field.GetValue(value) })
                    .ForEach(desc => desc.Field.SetValue(proxy, desc.Value));
     
                currentType = currentType.BaseType;
            } while (currentType != null);
     
            return proxy;
        }
    }
}
