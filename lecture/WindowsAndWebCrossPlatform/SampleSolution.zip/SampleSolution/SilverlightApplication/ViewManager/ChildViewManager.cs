﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel.Composition;
using System.Diagnostics;
using System.Windows;
using System.Windows.Threading;
using CrossPlatformApplication.ViewModel;
using CrossPlatformApplication.ViewModel.ViewModelManager;

#if SILVERLIGHT
using WindowType = System.Windows.Controls.ChildWindow;
#else
using WindowType = System.Windows.Window;
#endif

namespace CrossPlatformApplication.ViewManager
{
    /// <summary>
    /// Manager of child windows instances
    /// </summary>
    [Export]
    public class ChildViewManager
    {
        [ImportingConstructor]
        public ChildViewManager(IChildViewModelManager viewModelCollection)
        {
            OnViewModelCollectionChanged(viewModelCollection.ViewModels, new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));

            var notifiable = viewModelCollection.ViewModels as INotifyCollectionChanged;

            if (notifiable != null)
            {
                notifiable.CollectionChanged += (sender, e) => DispatcherSynchronizationContext.Post(arg => OnViewModelCollectionChanged(sender, e), null);
            }
        }

        // Private readonly fields
        protected static readonly DispatcherSynchronizationContext DispatcherSynchronizationContext = new DispatcherSynchronizationContext(
#if SILVERLIGHT
            Deployment.Current.Dispatcher
#else
            Application.Current.Dispatcher
#endif
        );

        // Private fields
        private readonly IDictionary<IChildViewModel, WindowType> _childViews = new Dictionary<IChildViewModel, WindowType>();

        /// <summary>
        /// Closes all managed <see cref="ChildViewPresenter" />
        /// </summary>
        protected virtual void CloseAllViews()
        {
            foreach (var pair in _childViews)
            {
                CloseView(pair.Key);
            }
        }

        /// <summary>
        /// Closes specified <see cref="ChildViewPresenter" />
        /// </summary>
        protected virtual void CloseView(IChildViewModel childViewModel)
        {
            Debug.Assert(_childViews.ContainsKey(childViewModel));

            WindowType childView = _childViews[childViewModel];
            _childViews.Remove(childViewModel);
            childView.Close();
        }

        /// <summary>
        /// Shows specified <see cref="ChildViewPresenter" />
        /// </summary>
        protected virtual void ShowView(IChildViewModel childViewModel)
        {
            WindowType childWindow = new ChildViewPresenter { DataContext = childViewModel };
            _childViews.Add(childViewModel, childWindow);
            childWindow.Show();
        }

        private void OnViewModelCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    foreach (IChildViewModel viewModel in e.NewItems)
                    {
                        ShowView(viewModel);
                    }
                    break;

                case NotifyCollectionChangedAction.Remove:
                    foreach (IChildViewModel viewModel in e.OldItems)
                    {
                        CloseView(viewModel);
                    }
                    break;

                case NotifyCollectionChangedAction.Reset:
                    CloseAllViews();

                    foreach (IChildViewModel viewModel in (IEnumerable) sender)
                    {
                        ShowView(viewModel);
                    }
                    break;

                default:
                    throw new ArgumentOutOfRangeException("e.Action is out of range", (Exception)null);
            }
        }
    }
}
