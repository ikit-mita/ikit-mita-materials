﻿using System.ComponentModel.Composition;

namespace CrossPlatformApplication
{
    [Export("TextInputModalChildView", typeof(IView))]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public partial class TextInputModalChildView : IView
    {
        public TextInputModalChildView()
        {
            InitializeComponent();
        }
    }
}
