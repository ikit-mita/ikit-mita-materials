﻿namespace CrossPlatformApplication
{
    public interface IView
    {
        object DataContext { set; }
    }
}
