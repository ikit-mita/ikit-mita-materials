﻿using System.Windows.Controls;

namespace CrossPlatformApplication
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
