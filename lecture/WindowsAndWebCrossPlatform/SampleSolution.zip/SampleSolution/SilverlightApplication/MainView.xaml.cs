﻿using System.ComponentModel.Composition;

namespace CrossPlatformApplication
{
    [Export("MainView", typeof(IView))]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public partial class MainView : IView
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
