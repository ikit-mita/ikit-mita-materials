﻿using System;
using System.Windows;
using System.Windows.Controls;
using CrossPlatformApplication.Utils;
using Microsoft.Practices.ServiceLocation;

namespace CrossPlatformApplication
{
    /// <summary>
    /// Presents a View corresponding to the View Model
    /// </summary>
    public class ViewModelPresenter : ContentControl
    {
        /// <summary>
        /// Initializes a new instance
        /// </summary>
        public ViewModelPresenter()
        {
            HorizontalContentAlignment = HorizontalAlignment.Stretch;
            VerticalContentAlignment = VerticalAlignment.Stretch;
        }

        // Dependency properties
        public static readonly DependencyProperty ViewModelProperty = DependencyProperty.Register(
            "ViewModel", typeof(object), typeof(ViewModelPresenter), new PropertyMetadata(null, OnViewModelPropertyChanged));

        // Private fields
        private Type _oldViewType;

        /// <summary>
        /// View Model to be presented
        /// </summary>
        public object ViewModel
        {
            get { return GetValue(ViewModelProperty); }
            set { SetValue(ViewModelProperty, value); }
        }

        private static void OnViewModelPropertyChanged(DependencyObject changedObject, DependencyPropertyChangedEventArgs args)
        {
            var contentControl = (ViewModelPresenter)changedObject;
            contentControl.RefreshContentPresenter();
        }

        private void RefreshContentPresenter()
        {
            if (ViewModel == null)
            {
                Content = null;
                _oldViewType = null;

                return;
            }

            IView view;
            Type viewModelType = ViewModel.GetType();

            do
            {
                view = ServiceLocator.Current.TryGetInstance<IView>(viewModelType.Name.Replace("ViewModel", "View"));

                if (view != null)
                {
                    break;
                }

                viewModelType = viewModelType.BaseType;
            } while (viewModelType != null);

            if (view != null)
            {
                Type viewType = view.GetType();

                if (viewType == _oldViewType && Content is IView)
                {
                    ((IView) Content).DataContext = ViewModel;
                }
                else
                {
                    view.DataContext = ViewModel;
                    Content = view;
                    _oldViewType = viewType;
                }
            }
            else
            {
                Content = "View hasn't been found";
                _oldViewType = null;
            }
        }
    }
}