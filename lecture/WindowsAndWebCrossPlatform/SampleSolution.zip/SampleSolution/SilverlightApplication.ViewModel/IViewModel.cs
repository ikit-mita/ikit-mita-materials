﻿namespace CrossPlatformApplication.ViewModel
{
    /// <summary>
    /// Base interface of a View Model
    /// </summary>
    public interface IViewModel
    {
        //
    }
}
