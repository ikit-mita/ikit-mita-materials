﻿using System;

namespace CrossPlatformApplication.ViewModel
{
    /// <summary>
    /// Base class of Child View's View Model providing its modal result
    /// </summary>
    public abstract class ModalChildViewModelBase : ChildViewModelBase, IModalChildViewModel
    {
        // Private fields
        private bool? _modalResult;

        /// <summary>
        /// Gets or sets modal result
        /// </summary>
        /// <remarks>
        /// Setting <see cref="ModalResult" /> causes View Model to close
        /// </remarks>
        public virtual bool? ModalResult
        {
            get { return _modalResult; }
            protected set
            {
                if (value == null)
                {
                    throw new InvalidOperationException("Unable to set ModalResult to null");
                }

                _modalResult = value;
                Close();
            }
        }
    }
}
