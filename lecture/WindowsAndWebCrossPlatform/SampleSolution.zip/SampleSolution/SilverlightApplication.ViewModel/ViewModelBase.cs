﻿namespace CrossPlatformApplication.ViewModel
{
    /// <summary>
    /// Base class for View Model
    /// </summary>
    public abstract class ViewModelBase : IViewModel
    {
        //
    }
}
