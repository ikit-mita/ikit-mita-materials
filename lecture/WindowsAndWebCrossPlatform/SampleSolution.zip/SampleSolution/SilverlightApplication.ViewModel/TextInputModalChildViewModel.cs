﻿using System.ComponentModel.Composition;
using CrossPlatformApplication.Utils;

namespace CrossPlatformApplication.ViewModel
{
    [Export]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [ExportMetadata(AopExtensions.AspectMetadata, Aspects.NotifyPropertyChanged)]
    public class TextInputModalChildViewModel : ModalChildViewModelBase
    {
        public virtual string Text { get; set; }
    }
}
