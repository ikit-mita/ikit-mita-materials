﻿using System.ComponentModel.Composition;
using CrossPlatformApplication.ViewModel.ViewModelManager;

namespace CrossPlatformApplication.ViewModel
{
    /// <summary>
    /// Base class for child window's View Model
    /// </summary>
    public abstract class ChildViewModelBase : CloseableViewModelBase, IChildViewModel
    {
        #region Injected properties

        [Import]
        public virtual ICloseableViewModelPresenter<IChildViewModel> ViewModelPresenter { get; set; }

        #endregion

        /// <summary>
        /// Registers View Model to be shown
        /// </summary>
        public override void Show()
        {
            ViewModelPresenter.ShowViewModel(this);
        }
    }
}
