﻿using System.ComponentModel.Composition;

namespace CrossPlatformApplication.ViewModel.ViewModelManager
{
    /// <summary>
    /// Manages child View Models
    /// </summary>
    [Export(typeof(IChildViewModelManager))]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public sealed class ChildViewModelManager : CloseableViewModelManagerBase<IChildViewModel>, IChildViewModelManager
    {
        //
    }
}
