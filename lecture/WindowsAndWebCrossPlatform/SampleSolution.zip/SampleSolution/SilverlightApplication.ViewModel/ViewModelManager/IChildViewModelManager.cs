﻿namespace CrossPlatformApplication.ViewModel.ViewModelManager
{
    /// <summary>
    /// Interface of Child View Model Manager
    /// </summary>
    public interface IChildViewModelManager : ICloseableViewModelManager<IChildViewModel>
    {
        //
    }
}
