﻿using System.ComponentModel.Composition;

namespace CrossPlatformApplication.ViewModel.ViewModelManager
{
    /// <summary>
    /// Interface of closeable View Model presenter
    /// </summary>
    [InheritedExport]
    public interface ICloseableViewModelPresenter<in TViewModelBase>
        where TViewModelBase : ICloseableViewModel
    {
        /// <summary>
        /// Shows <paramref name="viewModel" />
        /// </summary>
        void ShowViewModel(TViewModelBase viewModel);
    }
}
