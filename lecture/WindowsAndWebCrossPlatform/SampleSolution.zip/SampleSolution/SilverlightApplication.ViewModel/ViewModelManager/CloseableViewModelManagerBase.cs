﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace CrossPlatformApplication.ViewModel.ViewModelManager
{
    /// <summary>
    /// Manages closeable View Models of the specified type
    /// </summary>
    public abstract class CloseableViewModelManagerBase<TViewModelBase> : ICloseableViewModelManager<TViewModelBase>
        where TViewModelBase : ICloseableViewModel
    {
        // Private fields
        private readonly ObservableCollection<TViewModelBase> _viewModelsInternal = new ObservableCollection<TViewModelBase>();
        private ReadOnlyObservableCollection<TViewModelBase> _viewModels; // TODO: collection is not thread-safe

        /// <summary>
        /// Collection of managed View Models
        /// </summary>
        public ReadOnlyObservableCollection<TViewModelBase> ViewModels
        {
            get
            {
                return _viewModels ?? (_viewModels = new ReadOnlyObservableCollection<TViewModelBase>(_viewModelsInternal));
            }
        }

        #region ICloseableViewModelPresenter<TViewModelBase> Members

        void ICloseableViewModelPresenter<TViewModelBase>.ShowViewModel(TViewModelBase viewModel)
        {
            ShowViewModelCore(viewModel);
        }

        #endregion

        /// <summary>
        /// Closes <paramref name="viewModel" />
        /// </summary>
        protected virtual void CloseViewModelCore(TViewModelBase viewModel)
        {
            viewModel.Closed -= OnViewModelClosed;

            Debug.Assert(_viewModelsInternal.Contains(viewModel));
            _viewModelsInternal.Remove(viewModel);
        }

        /// <summary>
        /// Shows <paramref name="viewModel" />, adding it to collection
        /// </summary>
        protected virtual void ShowViewModelCore(TViewModelBase viewModel)
        {
            Debug.Assert(!viewModel.IsClosed);
            viewModel.Closed += OnViewModelClosed;

            Debug.Assert(!_viewModelsInternal.Contains(viewModel));
            _viewModelsInternal.Add(viewModel);
        }

        private void OnViewModelClosed(object sender, EventArgs e)
        {
            Debug.Assert(sender is TViewModelBase);
            CloseViewModelCore((TViewModelBase)sender);
        }
    }
}
