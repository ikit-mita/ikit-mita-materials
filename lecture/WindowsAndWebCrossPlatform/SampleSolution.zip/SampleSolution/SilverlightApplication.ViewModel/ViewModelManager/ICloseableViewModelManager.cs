﻿using System.Collections.ObjectModel;

namespace CrossPlatformApplication.ViewModel.ViewModelManager
{
    /// <summary>
    /// Interface of class managing closeable View Models of the specified type
    /// </summary>
    public interface ICloseableViewModelManager<TViewModelBase> : ICloseableViewModelPresenter<TViewModelBase>
        where TViewModelBase : ICloseableViewModel
    {
        /// <summary>
        /// Collection of managed View Models
        /// </summary>
        ReadOnlyObservableCollection<TViewModelBase> ViewModels { get; }
    }
}
