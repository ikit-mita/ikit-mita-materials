﻿namespace CrossPlatformApplication.ViewModel
{
    /// <summary>
    /// Interface of Child View's View Model
    /// </summary>
    public interface IChildViewModel : ICloseableViewModel, IEntitledViewModel
    {
        //
    }
}
