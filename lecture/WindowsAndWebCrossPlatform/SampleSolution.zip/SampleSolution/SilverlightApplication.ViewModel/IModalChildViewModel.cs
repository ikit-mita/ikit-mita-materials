﻿namespace CrossPlatformApplication.ViewModel
{
    /// <summary>
    /// Interface of Child View's View Model providing its modal result
    /// </summary>
    public interface IModalChildViewModel : IChildViewModel
    {
        /// <summary>
        /// View's modal result
        /// </summary>
        bool? ModalResult { get; }
    }
}
