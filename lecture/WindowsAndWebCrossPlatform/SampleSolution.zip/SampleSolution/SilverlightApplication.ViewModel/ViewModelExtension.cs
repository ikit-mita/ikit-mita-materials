﻿using System;
using System.Reactive.Linq;
using Microsoft.Practices.ServiceLocation;

namespace CrossPlatformApplication.ViewModel
{
    public static class ViewModelExtension
    {
        /// <summary>
        /// Resolves and shows Closeable View Model of type <typeparamref name="T" />
        /// </summary>
        public static IObservable<T> ResolveAndShow<T>(this IServiceLocator serviceLocator, Action<T> prepareAction = null)
            where T : ICloseableViewModel
        {
            var viewModel = serviceLocator.GetInstance<T>();

            if (prepareAction != null)
            {
                prepareAction(viewModel);
            }

            IObservable<T> result = Observable.FromEventPattern(handler => viewModel.Closed += handler, handler => viewModel.Closed -= handler)
                .SelectSender<T>();

            viewModel.Show();

            return result;
        }
    }
}
