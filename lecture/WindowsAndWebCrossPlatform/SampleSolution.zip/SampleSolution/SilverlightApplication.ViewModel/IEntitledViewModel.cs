﻿namespace CrossPlatformApplication.ViewModel
{
    /// <summary>
    /// Interface of a View Model that has a title
    /// </summary>
    public interface IEntitledViewModel : IViewModel
    {
        /// <summary>
        /// View Model's title
        /// </summary>
        string Title { get; }
    }
}
