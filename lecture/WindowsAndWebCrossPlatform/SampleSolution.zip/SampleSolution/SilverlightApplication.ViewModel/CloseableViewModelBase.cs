﻿using System;
using System.ComponentModel;
using System.Windows.Input;
using Microsoft.Expression.Interactivity.Core;

namespace CrossPlatformApplication.ViewModel
{
    /// <summary>
    /// Base class for View Model supporting closing
    /// </summary>
    public abstract class CloseableViewModelBase : EntitledViewModelBase, ICloseableViewModel
    {
        /// <summary>
        /// Shows whether a View Model has been closed
        /// </summary>
        public virtual bool IsClosed { get; private set; }

        #region Commands

        private ICommand _closeCommand;

        /// <summary>
        /// Command closing the tab
        /// </summary>
        public ICommand CloseCommand
        {
            get
            {
                return _closeCommand ??
                       (_closeCommand = new ActionCommand(Close));
            }
        }

        #endregion

        /// <summary>
        /// Event raised when the View Model is closed
        /// </summary>
        public event EventHandler Closed;

        /// <summary>
        /// Closes View Model
        /// </summary>
        public void Close()
        {
            if (IsClosed)
            {
                return;
            }

            var cancelEventArgs = new CancelEventArgs();
            OnClosing(cancelEventArgs);

            if (cancelEventArgs.Cancel)
            {
                return;
            }

            OnClosed();
        }

        /// <summary>
        /// Registers View Model to be shown
        /// </summary>
        public abstract void Show();

        /// <summary>
        /// Processes View Model closing attempt
        /// </summary>
        protected virtual void OnClosing(CancelEventArgs e)
        {
            //
        }

        /// <summary>
        /// Processes View Model close
        /// </summary>
        protected virtual void OnClosed()
        {
            IsClosed = true;

            if (Closed != null)
            {
                Closed(this, EventArgs.Empty);
            }
        }
    }
}
