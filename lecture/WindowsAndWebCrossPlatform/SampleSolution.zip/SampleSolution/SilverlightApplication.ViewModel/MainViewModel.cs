﻿using System.ComponentModel.Composition;
using System.Windows.Input;
using CrossPlatformApplication.Utils;
using Microsoft.Expression.Interactivity.Core;
using Microsoft.Practices.ServiceLocation;
using System;

namespace CrossPlatformApplication.ViewModel
{
    [Export]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [ExportMetadata(AopExtensions.AspectMetadata, Aspects.NotifyPropertyChanged)]
    public class MainViewModel : EntitledViewModelBase
    {
        // Private fields
        private string _text = "Hello world";

        public virtual string Text
        {
            get { return _text; }
            protected set { _text = value; }
        }

        #region Commands

        private ICommand _showTextInputCommand;

        public ICommand ShowTextInputCommand
        {
            get
            {
                return _showTextInputCommand ??
                       (_showTextInputCommand = new ActionCommand(ShowTextInput));
            }
        }

        #endregion

        #region Injected properties

        [Import]
        public IServiceLocator ServiceLocator { private get; set; }

        #endregion

        public override string Title
        {
            get { return "Test Application"; }
        }

        private void ShowTextInput()
        {
            ServiceLocator.ResolveAndShow<TextInputModalChildViewModel>()
                .WhereSucceeded()
                .Subscribe(vm => Text = vm.Text);
        }
    }
}
