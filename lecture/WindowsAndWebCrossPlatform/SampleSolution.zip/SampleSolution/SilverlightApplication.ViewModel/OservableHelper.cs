﻿using System;
using System.Reactive;
using System.Reactive.Linq;

namespace CrossPlatformApplication.ViewModel
{
public static class ObservableHelper
{
    public static IObservable<EventPattern<EventArgs>> ObserveClosed(this ICloseableViewModel childViewModel)
    {
        return Observable.FromEventPattern(
            handler => childViewModel.Closed += handler,
            handler => childViewModel.Closed -= handler);
    }

    public static IObservable<T> SelectSender<T>(this IObservable<EventPattern<EventArgs>> observable)
    {
        return observable.Select(ev => (T)ev.Sender);
    }

    public static IObservable<T> WhereSucceeded<T>(this IObservable<T> observable)
        where T : IModalChildViewModel
    {
        return observable.Where(vm => vm.ModalResult.HasValue && vm.ModalResult.Value);
    }
}
}
