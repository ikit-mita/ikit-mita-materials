﻿using System;

namespace CrossPlatformApplication.ViewModel
{
    /// <summary>
    /// Interface of a View Model that can be closed
    /// </summary>
    public interface ICloseableViewModel : IViewModel
    {
        /// <summary>
        /// Shows whether View Model has been closed
        /// </summary>
        bool IsClosed { get; }

        /// <summary>
        /// Event raised when the View Model is closed
        /// </summary>
        event EventHandler Closed;

        /// <summary>
        /// Closes View Model
        /// </summary>
        void Close();

        /// <summary>
        /// Registers View Model to be shown
        /// </summary>
        void Show();
    }
}
