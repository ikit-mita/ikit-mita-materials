﻿namespace CrossPlatformApplication.ViewModel
{
    /// <summary>
    /// Base class for View Model that has title
    /// </summary>
    public abstract class EntitledViewModelBase : ViewModelBase, IEntitledViewModel
    {
        /// <summary>
        /// View Model's title
        /// </summary>
        public virtual string Title
        {
            get { return "Безымянный"; }
        }
    }
}
